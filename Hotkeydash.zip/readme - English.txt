             _   _                  _           _     
  /\  /\___ | |_| | _____ _   _  __| | __ _ ___| |__  
 / /_/ / _ \| __| |/ / _ \ | | |/ _` |/ _` / __| '_ \ 
/ __  / (_) | |_|   <  __/ |_| | (_| | (_| \__ \ | | |
\/ /_/ \___/ \__|_|\_\___|\__, |\__,_|\__,_|___/_| |_|
                          |___/                       

This GDI malware was made by xnine.

Here are the things you should probably do before running this program.

1. Install Windows Media Player. Just so that the bytebeats play. Without it installed, it wont play and instead shows the Windows Media Player installation window.

2. Run this in a Safe Environment. This is a malware that can overwrite the MBR, disable Task Manager and the Registry Editor. So if you are running this on a real PC in a unsafe environment, Run the harmless version instead. If you are in a sandbox, VM, a old PC you don't use etc.

3. For skidders. If you are using something from the source code, Credit me.

4. At the end. If you run the harmful edition. It will cause a BSOD at the end, after restart you wont be in your OS again. So make sure you have a recovery USB or something like that.

5. Do NOT run these malwares maliciously. This is illegal and can get you in trouble if you run these kind of malwares (worms, ransomware etc.) maliciously. This program is for educational purposes only.

6. Turn off all antivirus software. This prevents your antivirus from blocking, removing or quarantine this malware.

Make sure you have read all of this.

Thank you.

Made by xnine

19.09.2026